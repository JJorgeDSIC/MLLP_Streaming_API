#  Copyright 2020 the MLLP-VRAIN research grup
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#  http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""
## The MLLP-TTP gRPC Streaming API Python3 client library (v1.0)

The [MLLP-TTP](https://ttp.mllp.upv.es/) gRPC Streaming API Python3 client library can be used to develop your own streaming
speech recognition application/backend, or also as a standalone command-line
tool to transcribe audio files. It is based on the gRPC framework.

Installation (via a provided .whl file): 

```bash
pip install MLLPStreamingClient_mllp-${VERSION}-py3-none-any.whl 
```

Below are shown some examples on interacting with the gRPC Streaming API with this library.

First, we have to import the `MLLPStreamingClient` library and create a `MLLPStreamingClient` class instance:

```python
from MLLPStreamingClient import MLLPStreamingClient
cli = MLLPStreamingClient(server_hostname, server_port, api_user, 
                          api_secret, server_ssl_cert_file)
```

_server_hostname_, _server_port_, _api_user_, _api_secret_ and _server_ssl_cert_file_ are
given in the [API section of TTP](https://ttp.mllp.upv.es/index.php?page=api).

Next, and optionally, we can perform a explicit call to the rpc GetAuthToken method, to get a valid auth token
for the nextcoming rpc calls:

```python
 cli.getAuthToken()
```

Please note that if we do not perform explicitly this call, it will be performed implicitly by the library, if necessary.

Then, we check out the available transcription (ASR) systems offered by the service by calling to the GetTranscribeSystemsInfo rpc call:

```python
 systems = cli.getTranscribeSystemsInfo()
 import json
 print(json.dumps(systems, indent=4))
```

Finally, we pick up one system (`system_id`) and start transcribing our live
audio stream supplied as an iterator method called i.e. `myStreamIterator()`, while
printing only consolidated transcription chunks:

```python
for resp in cli.transcribe(system_id, myStreamIterator):
    if resp["hyp_novar"] != "":
        sys.stdout.write("%s " % resp["hyp_novar"].strip())
        if resp["eos"] == True:
            sys.stdout.write("\\n")
        sys.stdout.flush()
```

Please note that consolidated transcription chunks (`resp["hyp_novar"]`) are
be delivered with far more latency than non-consolidated, ongoing (live) ones
(given by `resp["hyp_var"]`). However, these latter chunks grow and change
as new incoming audio data is processed, until the system
decides to consolidate. 

An easy way to test the service, or in case you want to use it in an off-line
fashion, is to stream a raw audio file compilant with the audio specifications, that
is: PCM, single channel, 16khz sample rate, 16bit little endian.

```python
def myStreamIterator():
    with open("test.wav", "rb") as fd:
        data = fd.read(250)
        while data != b"":
            yield data
            data = fd.read(250)
```

However, if you want to perform a more realistic test, you can try to stream your
own voice using a microphone and
[pyAudio](http://people.csail.mit.edu/hubert/pyaudio/):

```python
import pyaudio
def myStreamIterator():
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 16000
    RECORD_SECONDS = 20
    p = pyaudio.PyAudio()
    stream = p.open(format=FORMAT,
                     channels=CHANNELS,
                     rate=RATE,
                     input=True,
                     frames_per_buffer=CHUNK)
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        yield data
    stream.stop_stream()
    stream.close()
    p.terminate()
```
    
If your audio file or stream does not comply with these specs, you should consider
to transform it before delivering it to the service, i.e. by using [pydub.AudioSegment](http://pydub.com/)
"""

__all__ = ["MLLPStreamingClient"]

import sys
import grpc
import google.protobuf.empty_pb2 as empty_pb2
import google.protobuf.json_format as json_format
import logging
from datetime import datetime
import MLLPStreamingClient.mllp_streaming_pb2_grpc as mllp_streaming_pb2_grpc
import MLLPStreamingClient.mllp_streaming_pb2 as mllp_streaming_pb2


class MLLPStreamingClient():


    _SIGNATURE_HEADER_KEY = 'x-mllp-auth-token'

    def __init__(self, server_name, server_port, api_user=None, api_secret_key=None, server_cert_file=None, debug=False):
        """
        Creates a MLLPStreamingClient instance. 
    
        Parameters:
       
        - **_server_name_**: gRPC API server hostname or IP address.
        - **_server_port_**: gRPC API server port.
        - **_api_user_**: TTP API username (optional, if server does not require user auth).
        - **_api_secret_key_**: TTP API user secret key (optional, if server does not require user auth).
        - **_server_cert_file_** (optional): use SSL encryption, by providing an SSL certificate file of the gRPC API server.
        - **_debug_** (optional): enable/disable debug mode.
        """
        self._hostname = server_name
        self._port = server_port
        self._api_user = api_user
        self._api_secret = api_secret_key
        if server_cert_file != None:
            with open(server_cert_file, 'rb') as fd:
                self._server_cert = fd.read()
            self._ssl_credentials = grpc.ssl_channel_credentials(root_certificates=self._server_cert)
        else:
            self._server_cert = None
            self._ssl_credentials = None
        self._auth_token = None
        self._auth_token_expires = None
        self._credentials = None
        self.__create_logger(debug)
  
    def __create_logger(self, debug):
        """
        Init logger.
        """
        self._logger = logging.getLogger("MLLP Streaming Client")
        ch = logging.StreamHandler()
        if debug:
            self._logger.setLevel(logging.DEBUG)
            ch.setLevel(logging.DEBUG)
        else:
            self._logger.setLevel(logging.INFO)
            ch.setLevel(logging.INFO)
        formatter = logging.Formatter('[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s')
        ch.setFormatter(formatter)
        self._logger.addHandler(ch)
 
    def __dd(self, msg):
        self._logger.debug(msg);

    def __ii(self, msg):
        self._logger.info(msg);

    def __ww(self, msg):
        self._logger.warning(msg);

    def __ee(self, msg):
        self._logger.error(msg);

    def __generateCredentials(self):
        """
        Sets up self._credentials for nextcoming gRPC calls.
        """
        self._credentials = grpc.metadata_call_credentials(
           MLLPStreamingClient._AuthGateway(self._auth_token), None)
        if self._ssl_credentials != None:
            self._credentials = grpc.composite_channel_credentials(
                self._ssl_credentials, self._credentials)

    def __isAuth(self):
        """
        Checks if the client has a valid authentication token
        """
        return self._auth_token != None and self._auth_token_expires > datetime.now().timestamp()

    def __createChannel(self):
        if self._server_cert != None:
            return grpc.secure_channel("%s:%s" % (self._hostname, self._port), self._credentials)
        else:
            return grpc.insecure_channel("%s:%s" % (self._hostname, self._port))

    def __toJson(self, response):
        """
        Converts gRPC message to JSON (python dictionary)
        """
        return json_format.MessageToDict(response, 
            including_default_value_fields=True, 
            use_integers_for_enums=True,
            preserving_proto_field_name=True)

    def __toTranscribeRequestGenerator(self, system_id, audio_stream_iterator):
        """
        Converts the provided audio stream to TranscribeRequest messages
        """
        yield mllp_streaming_pb2.TranscribeRequest(system_id=system_id)
        for data in audio_stream_iterator():
            yield mllp_streaming_pb2.TranscribeRequest(data=data)


    def getAuthToken(self):
        """
        Implements the gRPC GetAuthToken call, to get a valid auth token for nextcoming gRPC calls.
    
        Explicitly calls to GetAuthToken with the API user name and API user secret provided to the class constructor. 
        Auth token and its lifetime is saved in this instance for the nextcoming gRPC calls.
        
        Returns an AuthTokenResponse in JSON format (python dictionary).
    
        Raises Exception if the server returns an error code, typically when authentication fails.
        """ 
        if self._credentials == None:
            self.__generateCredentials()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            resp = stub.GetAuthToken(mllp_streaming_pb2.AuthTokenRequest(user=self._api_user, password=self._api_secret))
        self.__dd("(GetAuthToken)\n%s" % self.__toJson(resp))
        if resp.code == mllp_streaming_pb2.AuthTokenResponse.Code.ERR:
            msg = "(GetAuthToken): auth failed (server returned AuthTokenResponse.Code.ERR)"
            self.__ee(msg)
            raise Exception(msg)
        self._auth_token = resp.auth_token
        self._auth_token_expires = resp.expiry_date
        self.__generateCredentials() # generate credentials with the given auth token
        self.__dd("Authentication successful as user '%s' (expires on: %s)" % (self._api_user, datetime.fromtimestamp(self._auth_token_expires).strftime("%Y-%m-%d %H:%M:%S")))
        return self.__toJson(resp)
         

    def getTranscribeSystemsInfo(self):
        """
        Implements the gRPC GetTranscribeSystemsInfo call, to get information about all available streaming transcription (ASR) systems.
    
        Returns a list of TranscribeSystemsInfoResponse in JSON format (python dictionaries).
    
        This method automatically calls to getAuthToken(), if the MLLPStreamingClient object does not store a valid auth token. 
        """

        if not(self.__isAuth()):
            self.getAuthToken()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            systems = []
            if self._ssl_credentials == None:
                metadata = [(MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._auth_token)] 
            else:
                metadata=None
            for resp in stub.GetTranscribeSystemsInfo(empty_pb2.Empty(), metadata=metadata):
                self.__dd("(GetTranscribeSystemsInfo)\n%s" % self.__toJson(resp))
                systems.append(self.__toJson(resp))
        return systems


    def transcribe(self, system_id, audio_stream_iterator):
        """
        Implements the gRPC Transcribe call, to transcribe a stream of raw audio samples using a streaming transcription (ASR) system.
    
        Parameters:
       
        - **_system_id_**: Transcription (ASR) system identifier (obtained in a previous call to getTranscribeSystemsInfo()). 
        - **_audio_stream_iterator_**: a iterator or a generator method providing chuncks of raw audio data (i.e. wav) in the following format: single channel (mono), 16khz, signed 16bit little endian.
    
        This method is a generator of TranscribeResponse gRPC messages in JSON format (python dictionaries), thus providing as output a continuous stream of transcriptions for the incoming audio stream feeded by **_audio_stream_iterator_**.
    
        This method automatically calls to getAuthToken(), if the MLLPStreamingClient object does not store a valid auth token.
        """

        if not(self.__isAuth()):
           self.getAuthToken()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            if self._ssl_credentials == None:
                metadata = [(MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._auth_token)] 
            else:
                metadata=None
            for resp in stub.Transcribe(self.__toTranscribeRequestGenerator(system_id, audio_stream_iterator), metadata=metadata):
                self.__dd(self.__toJson(resp))
                yield self.__toJson(resp)

    def addASRNode(self, host, port):
        """
        Admin method: implements the gRPC AddASRNode call.
        """

        if not(self.__isAuth()):
           self.getAuthToken()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            if self._ssl_credentials == None:
                metadata = [(MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._auth_token)] 
            else:
                metadata=None
            resp = stub.AddASRNode(mllp_streaming_pb2.AddASRNodeRequest(host=host, port=port), metadata=metadata)
        self.__dd("(addASRNode)\n%s" % self.__toJson(resp))
        return self.__toJson(resp)

    def listASRNodes(self):
        """
        Admin method: implements the gRPC ListASRNodes call.
        """

        if not(self.__isAuth()):
           self.getAuthToken()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            nodes = []
            if self._ssl_credentials == None:
                metadata = [(MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._auth_token)] 
            else:
                metadata=None
            for resp in stub.ListASRNodes(empty_pb2.Empty(), metadata=metadata):
                self.__dd("(listASRNodes)\n%s" % self.__toJson(resp))
                nodes.append(self.__toJson(resp))
        return nodes

    def removeASRNode(self, host, port):
        """
        Admin method: implements the gRPC RemoveASRNode call.
        """

        if not(self.__isAuth()):
           self.getAuthToken()
        with self.__createChannel() as channel:
            stub = mllp_streaming_pb2_grpc.MLLPStreamingStub(channel)
            if self._ssl_credentials == None:
                metadata = [(MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._auth_token)] 
            else:
                metadata=None
            resp = stub.RemoveASRNode(mllp_streaming_pb2.RemoveASRNodeRequest(host=host, port=port), metadata=metadata)
        self.__dd("(removeASRNode)\n%s" % self.__toJson(resp))
        return self.__toJson(resp)

 
    class _AuthGateway(grpc.AuthMetadataPlugin):
        """
        Internal class to provide authentication token as metadata in all gRPC calls.
        """

        def __init__(self, jwt):
            self._jwt = jwt
    
        def __call__(self, context, callback):
            callback(((MLLPStreamingClient._SIGNATURE_HEADER_KEY, self._jwt),), None)
    
    
